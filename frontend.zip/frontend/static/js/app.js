/* ══════════════════════════════════════════════════════════
   USER APP — app.js
   Fonctions : consulter, télécharger, ouvrir, fusionner, favoris
   ══════════════════════════════════════════════════════════ */

/* ── Utilitaires ─────────────────────────────────────────── */
function toast(msg, type = 'info') {
  const c = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  c.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

function sizeStr(bytes) {
  if (!bytes) return null;
  return bytes > 1048576
    ? (bytes / 1048576).toFixed(1) + ' MB'
    : (bytes / 1024).toFixed(1) + ' KB';
}

function paginationRange(cur, total, delta = 2) {
  const range = [1];
  const l = Math.max(2, cur - delta), r = Math.min(total - 1, cur + delta);
  if (l > 2) range.push('…');
  for (let i = l; i <= r; i++) range.push(i);
  if (r < total - 1) range.push('…');
  if (total > 1) range.push(total);
  return range;
}

function renderPagination(elId, page, totalPages, loadFn, kws) {
  const el = document.getElementById(elId);
  if (!el) return;
  if (totalPages <= 1) { el.innerHTML = ''; return; }
  const pages = paginationRange(page, totalPages);
  const kp = JSON.stringify(kws || []);
  el.innerHTML = `
    <button class="pg-btn" onclick='${loadFn}(${kp},1)' ${page===1?'disabled':''}>«</button>
    <button class="pg-btn" onclick='${loadFn}(${kp},${page-1})' ${page===1?'disabled':''}>‹</button>
    ${pages.map(p => p==='…'
      ? `<span class="pg-ellipsis">…</span>`
      : `<button class="pg-btn ${p===page?'active':''}" onclick='${loadFn}(${kp},${p})'>${p}</button>`
    ).join('')}
    <button class="pg-btn" onclick='${loadFn}(${kp},${page+1})' ${page===totalPages?'disabled':''}>›</button>
    <button class="pg-btn" onclick='${loadFn}(${kp},${totalPages})' ${page===totalPages?'disabled':''}>»</button>
    <span class="pg-info">Page ${page} / ${totalPages}</span>`;
}

/* ── Favoris ─────────────────────────────────────────────── */
function getSessionKey() {
  let k = localStorage.getItem('fav_session_key');
  if (!k) {
    k = 'sk-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem('fav_session_key', k);
  }
  return k;
}

let favoriteSet = new Set();

async function loadFavSet() {
  try {
    const sk = getSessionKey();
    const favs = await API.get(`/favorites/?session_key=${encodeURIComponent(sk)}`);
    favoriteSet.clear();
    (favs || []).forEach(f => {
      if (f.found_file_id)    favoriteSet.add(`found-${f.found_file_id}`);
      if (f.uploaded_file_id) favoriteSet.add(`uploaded-${f.uploaded_file_id}`);
    });
  } catch (e) { console.error(e); }
}

function isFav(source, id) { return favoriteSet.has(`${source}-${id}`); }

async function toggleFav(source, id, event) {
  if (event) event.stopPropagation();
  const sk = getSessionKey();
  const payload = { session_key: sk };
  if (source === 'found') payload.found_file_id = id;
  else payload.uploaded_file_id = id;
  try {
    const res = await API.post('/favorites/toggle', payload);
    if (res.action === 'added') {
      favoriteSet.add(`${source}-${id}`);
      toast('Ajouté aux favoris ❤', 'success');
    } else {
      favoriteSet.delete(`${source}-${id}`);
      toast('Retiré des favoris', 'info');
    }
    const btn = document.getElementById(`fav-btn-${source}-${id}`);
    if (btn) btn.classList.toggle('fav-active', res.action === 'added');
    if (document.getElementById('view-favorites')?.classList.contains('active')) loadFavorites();
  } catch (e) { toast('Erreur favoris', 'error'); }
}

function favBtn(source, id) {
  const active = isFav(source, id);
  return `<button class="fav-btn ${active ? 'fav-active' : ''}" id="fav-btn-${source}-${id}"
    title="${active ? 'Retirer des favoris' : 'Ajouter aux favoris'}"
    onclick="toggleFav('${source}','${id}',event)">❤</button>`;
}

/* ── Card builder ────────────────────────────────────────── */
function buildCard({ id, source, filename, file_size, has_thumbnail, thumbPath, statusBadge, subline = '', extraBtns = '', isSelected = false }) {
  const sz = sizeStr(file_size);
  return `
  <div class="file-card ${isSelected ? 'selected' : ''}" id="${source}-card-${id}" onclick="cardClick('${source}','${id}',event)">
    ${favBtn(source, id)}
    <div class="file-card-check">
      <input type="checkbox" id="${source}-cb-${id}" ${isSelected ? 'checked' : ''}
        onchange="cardCheck('${source}','${id}',event)" onclick="event.stopPropagation()">
    </div>
    <div class="file-card-thumb">
      ${has_thumbnail && thumbPath
        ? `<img src="${thumbPath}" alt="aperçu" loading="lazy" onerror="this.parentElement.innerHTML='<div class=\\'thumb-placeholder\\'>PDF</div>'">`
        : `<div class="thumb-placeholder">PDF</div>`}
    </div>
    <div class="file-card-info">
      <div class="file-card-name" title="${filename}">${filename}</div>
      <div class="file-card-meta">
        ${sz ? `<span class="meta-size">📦 ${sz}</span>` : ''}
        ${statusBadge}
      </div>
      ${subline ? `<div class="file-card-url" title="${subline}">${subline}</div>` : ''}
      ${extraBtns}
    </div>
  </div>`;
}

/* ── État ───────────────────────────────────────────────────*/
let foundFiles = [], downloadedFiles = [];
let selectedFoundIds = new Set(), selectedDlIds = new Set();
let activeFoundKws = [], activeDlKws = [];
let foundPag = { page:1, page_size:20, total:0, total_pages:1 };
let dlPag    = { page:1, page_size:20, total:0, total_pages:1 };
let mergeContext = null;

/* ── Vues ────────────────────────────────────────────────── */
function switchView(view) {
  document.querySelectorAll('.main-view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const el = document.getElementById(`view-${view}`);
  if (el) el.classList.add('active');
  const btn = document.querySelector(`[data-view="${view}"]`);
  if (btn) btn.classList.add('active');
  if (view === 'downloaded') loadDownloadedFiles(activeDlKws);
  if (view === 'favorites')  loadFavorites();
}

/* ── Fichiers découverts ─────────────────────────────────── */
async function loadFoundFiles(kws = [], page = null) {
  if (page !== null) foundPag.page = page;
  activeFoundKws = Array.isArray(kws) ? kws : [];
  const qs = `?page=${foundPag.page}&page_size=${foundPag.page_size}` +
    (activeFoundKws.length ? `&keywords=${encodeURIComponent(activeFoundKws.join(','))}` : '');
  try {
    const data = await API.get('/files/' + qs);
    foundFiles = data.items || [];
    foundPag = { page: data.page, page_size: data.page_size, total: data.total, total_pages: data.total_pages };
    renderFoundCards();
  } catch (e) { console.error(e); }
}

function renderFoundCards() {
  const c = document.getElementById('found-cards');
  if (!c) return;
  if (!foundFiles.length) {
    c.innerHTML = `<div class="cards-empty">Aucun fichier trouvé</div>`;
    renderPagination('found-pagination', foundPag.page, foundPag.total_pages, 'loadFoundFiles', activeFoundKws);
    return;
  }
  c.innerHTML = foundFiles.map(f => buildCard({
    id: f.id, source: 'found', filename: f.filename, file_size: f.file_size,
    has_thumbnail: f.has_thumbnail,
    thumbPath: `/api/files/${f.id}/thumbnail`,
    statusBadge: f.is_downloaded
      ? `<span class="meta-dl">⬇ Téléchargé</span>`
      : `<span class="meta-new">🔗 Découvert</span>`,
    subline: f.url,
    isSelected: selectedFoundIds.has(f.id),
    extraBtns: `<div class="card-actions">
      ${f.is_downloaded
        ? `<button class="btn btn-sm" onclick="event.stopPropagation();viewFile('found','${f.id}')">👁 Voir</button>
           <a class="btn btn-sm btn-secondary" href="/api/files/${f.id}/serve" download>⬇</a>`
        : `<button class="btn btn-sm btn-primary" onclick="event.stopPropagation();downloadOne('${f.id}')">⬇ Télécharger</button>`}
    </div>`,
  })).join('');
  renderPagination('found-pagination', foundPag.page, foundPag.total_pages, 'loadFoundFiles', activeFoundKws);
}

async function searchFoundFiles() {
  const tags = getKeywords('search-kw-tags');
  activeFoundKws = tags;
  await loadFoundFiles(activeFoundKws, 1);
}

/* ── Fichiers téléchargés / uploadés ────────────────────── */
async function loadDownloadedFiles(kws = [], page = null) {
  if (page !== null) dlPag.page = page;
  activeDlKws = Array.isArray(kws) ? kws : [];
  const qs = `?page=${dlPag.page}&page_size=${dlPag.page_size}` +
    (activeDlKws.length ? `&keywords=${encodeURIComponent(activeDlKws.join(','))}` : '');
  try {
    const data = await API.get('/files/downloaded' + qs);
    downloadedFiles = data.items || [];
    dlPag = { page: data.page, page_size: data.page_size, total: data.total, total_pages: data.total_pages };
    renderDlCards();
  } catch (e) { console.error(e); }
}

function renderDlCards() {
  const c = document.getElementById('dl-cards');
  if (!c) return;
  if (!downloadedFiles.length) {
    c.innerHTML = `<div class="cards-empty">Aucun fichier disponible</div>`;
    renderPagination('dl-pagination', dlPag.page, dlPag.total_pages, 'loadDownloadedFiles', activeDlKws);
    return;
  }
  c.innerHTML = downloadedFiles.map(f => {
    const isUp = f.file_type === 'uploaded';
    const thumbPath = isUp ? `/api/upload/${f.id}/thumbnail` : `/api/files/${f.id}/thumbnail`;
    const servePath = isUp ? `/api/upload/${f.id}/serve`     : `/api/files/${f.id}/serve`;
    const viewPath  = isUp ? `/api/upload/${f.id}/view`      : `/api/files/${f.id}/view`;
    const src = isUp ? 'uploaded' : 'found';
    return buildCard({
      id: f.id, source: src, filename: f.filename, file_size: f.file_size,
      has_thumbnail: f.has_thumbnail, thumbPath,
      statusBadge: isUp ? `<span class="meta-dl">⬆ Uploadé</span>` : `<span class="meta-dl">⬇ Crawlé</span>`,
      isSelected: selectedDlIds.has(`${src}-${f.id}`),
      extraBtns: `<div class="card-actions">
        <button class="btn btn-sm" onclick="event.stopPropagation();window.open('${viewPath}','_blank')">👁 Voir</button>
        <a class="btn btn-sm btn-secondary" href="${servePath}" download>⬇</a>
      </div>`,
    });
  }).join('');
  renderPagination('dl-pagination', dlPag.page, dlPag.total_pages, 'loadDownloadedFiles', activeDlKws);
}

async function searchDownloadedFiles() {
  activeDlKws = getKeywords('dl-kw-tags');
  await loadDownloadedFiles(activeDlKws, 1);
}

/* ── Sélection ───────────────────────────────────────────── */
function cardClick(source, id, e) {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
  cardCheck(source, id, e);
}

function cardCheck(source, id, e) {
  if (e) e.stopPropagation();
  const key = `${source}-${id}`;
  const cb = document.getElementById(`${source}-cb-${id}`);
  const card = document.getElementById(`${source}-card-${id}`);

  if (source === 'found') {
    if (selectedFoundIds.has(id)) { selectedFoundIds.delete(id); }
    else { selectedFoundIds.add(id); }
    if (cb) cb.checked = selectedFoundIds.has(id);
    if (card) card.classList.toggle('selected', selectedFoundIds.has(id));
    updateFoundSelHint();
  } else {
    if (selectedDlIds.has(key)) { selectedDlIds.delete(key); }
    else { selectedDlIds.add(key); }
    if (cb) cb.checked = selectedDlIds.has(key);
    if (card) card.classList.toggle('selected', selectedDlIds.has(key));
    updateDlSelHint();
  }
}

function updateFoundSelHint() {
  const el = document.getElementById('found-sel-hint');
  if (el) el.textContent = selectedFoundIds.size ? `${selectedFoundIds.size} sélectionné(s)` : '';
}

function updateDlSelHint() {
  const el = document.getElementById('dl-sel-hint');
  if (el) el.textContent = selectedDlIds.size ? `${selectedDlIds.size} sélectionné(s)` : '';
}

/* ── Téléchargement ──────────────────────────────────────── */
async function downloadOne(fileId) {
  try {
    toast('Téléchargement en cours…', 'info');
    await API.post(`/files/${fileId}/download`, {});
    toast('Téléchargé ✔', 'success');
    await loadFoundFiles(activeFoundKws);
    await loadDownloadedFiles(activeDlKws);
  } catch (e) { toast(e.detail || 'Erreur', 'error'); }
}

async function downloadSelected() {
  if (!selectedFoundIds.size) { toast('Sélectionnez des fichiers', 'error'); return; }
  let ok = 0, fail = 0;
  toast(`Téléchargement de ${selectedFoundIds.size} fichier(s)…`, 'info');
  for (const id of selectedFoundIds) {
    try { await API.post(`/files/${id}/download`, {}); ok++; }
    catch { fail++; }
  }
  toast(`${ok} téléchargé(s)${fail ? `, ${fail} échoué(s)` : ''} ✔`, ok ? 'success' : 'error');
  selectedFoundIds.clear();
  await loadFoundFiles(activeFoundKws);
  await loadDownloadedFiles(activeDlKws);
}

/* ── Fusion ──────────────────────────────────────────────── */
function openMergeModal(files) {
  const names = files.map(f => f.filename || f.id).join(', ');
  document.getElementById('merge-modal-title').textContent = `Fusionner ${files.length} fichier(s)`;
  document.getElementById('merge-info').innerHTML =
    `<strong>${files.length} fichiers</strong> : <span style="color:#f43f5e">${names}</span>`;
  document.getElementById('merge-filename').value = 'fusion.pdf';
  mergeContext = files;
  document.getElementById('modal-merge').classList.add('open');
}

function mergeSelectedDl() {
  if (selectedDlIds.size < 2) { toast('Sélectionnez au moins 2 fichiers', 'error'); return; }
  const files = [...selectedDlIds].map(k => {
    const [type, id] = k.split('-');
    return { id, file_type: type === 'uploaded' ? 'uploaded' : 'found',
      filename: downloadedFiles.find(f => f.id === id)?.filename || id };
  });
  openMergeModal(files);
}

function closeMergeModal() {
  document.getElementById('modal-merge').classList.remove('open');
  mergeContext = null;
}

async function confirmMerge() {
  if (!mergeContext) return;
  const output = document.getElementById('merge-filename').value.trim() || 'fusion.pdf';
  const files = mergeContext === 'favorites'
    ? (window._favsMergeList || []).map(f => ({
        id: f.file_id, file_type: f.source === 'uploaded' ? 'uploaded' : 'found'
      }))
    : mergeContext.map(f => ({ id: f.id, file_type: f.file_type || 'found' }));

  if (files.length < 2) { toast('Au moins 2 fichiers requis', 'error'); return; }
  const btn = document.getElementById('merge-confirm-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Fusion…'; }

  try {
    const token = Auth.getToken();
    const r = await fetch('/api/files/merge', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ files, output_filename: output }),
    });
    if (!r.ok) { const e = await r.json().catch(() => ({})); throw e; }
    const blob = await r.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = output;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    toast('PDF fusionné téléchargé ✔', 'success');
    closeMergeModal();
    selectedDlIds.clear();
    updateDlSelHint();
  } catch (e) {
    toast(e.detail || 'Erreur de fusion', 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '✔ Fusionner et télécharger'; }
  }
}

/* ── Favoris page ────────────────────────────────────────── */
async function loadFavorites() {
  const c = document.getElementById('fav-cards');
  if (!c) return;
  try {
    const sk = getSessionKey();
    const favs = await API.get(`/favorites/?session_key=${encodeURIComponent(sk)}`);
    favoriteSet.clear();
    (favs || []).forEach(f => {
      if (f.found_file_id)    favoriteSet.add(`found-${f.found_file_id}`);
      if (f.uploaded_file_id) favoriteSet.add(`uploaded-${f.uploaded_file_id}`);
    });
    const cnt = document.getElementById('fav-count');
    if (cnt) cnt.textContent = favs.length ? `${favs.length} favori(s)` : '';

    if (!favs.length) {
      c.innerHTML = `<div class="cards-empty">Aucun favori — cliquez ❤ sur un fichier pour en ajouter</div>`;
      return;
    }
    c.innerHTML = favs.map(f => {
      const isUp = f.source === 'uploaded';
      const thumbPath = isUp ? `/api/upload/${f.file_id}/thumbnail` : `/api/files/${f.file_id}/thumbnail`;
      const viewPath  = isUp ? `/api/upload/${f.file_id}/view`      : `/api/files/${f.file_id}/view`;
      const servePath = isUp ? `/api/upload/${f.file_id}/serve`      : `/api/files/${f.file_id}/serve`;
      return `
      <div class="file-card" id="fav-card-${f.id}">
        <button class="fav-btn fav-active" onclick="removeFav('${f.id}',event)" title="Retirer">❤</button>
        <div class="file-card-thumb">
          ${f.has_thumbnail
            ? `<img src="${thumbPath}" alt="aperçu" loading="lazy" onerror="this.parentElement.innerHTML='<div class=\\'thumb-placeholder\\'>PDF</div>'">`
            : `<div class="thumb-placeholder">PDF</div>`}
        </div>
        <div class="file-card-info">
          <div class="file-card-name" title="${f.filename}">${f.filename}</div>
          <div class="file-card-meta">
            ${sizeStr(f.file_size) ? `<span class="meta-size">📦 ${sizeStr(f.file_size)}</span>` : ''}
            <span class="meta-dl">${isUp ? '⬆ Uploadé' : '🔗 Crawlé'}</span>
          </div>
          <div class="card-actions">
            <button class="btn btn-sm" onclick="window.open('${viewPath}','_blank')">👁 Voir</button>
            <a class="btn btn-sm btn-secondary" href="${servePath}" download>⬇</a>
          </div>
        </div>
      </div>`;
    }).join('');
  } catch (e) { console.error(e); }
}

async function removeFav(favId, event) {
  if (event) event.stopPropagation();
  try {
    await API.delete(`/favorites/${favId}`);
    toast('Retiré des favoris', 'info');
    await loadFavorites();
  } catch (e) { toast('Erreur', 'error'); }
}

async function mergeFavorites() {
  const sk = getSessionKey();
  let favs;
  try { favs = await API.get(`/favorites/?session_key=${encodeURIComponent(sk)}`); }
  catch (e) { toast('Erreur chargement favoris', 'error'); return; }
  if (!favs || favs.length < 2) { toast('Il faut au moins 2 favoris', 'error'); return; }
  window._favsMergeList = favs;
  mergeContext = 'favorites';
  document.getElementById('merge-modal-title').textContent = 'Fusionner les favoris';
  document.getElementById('merge-info').innerHTML =
    `<strong>${favs.length} favoris</strong> : <span style="color:#f43f5e">${favs.map(f=>f.filename).join(', ')}</span>`;
  document.getElementById('merge-filename').value = 'favoris_fusionnes.pdf';
  document.getElementById('modal-merge').classList.add('open');
}

/* ── Keyword input ───────────────────────────────────────── */
function setupKeywordInput(inputId, containerId, onChangeFn) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ',') && input.value.trim()) {
      e.preventDefault();
      addTag(input.value.trim(), document.getElementById(containerId), input);
      if (onChangeFn) onChangeFn();
    }
    if (e.key === 'Backspace' && !input.value) {
      const c = document.getElementById(containerId);
      const tags = c?.querySelectorAll('.kw-tag');
      if (tags?.length) tags[tags.length - 1].remove();
      if (onChangeFn) onChangeFn();
    }
  });
}

function addTag(value, container, input) {
  if (!container || !value) return;
  const tag = document.createElement('span');
  tag.className = 'kw-tag';
  tag.innerHTML = `${value} <span class="kw-tag-del" onclick="this.parentElement.remove()">×</span>`;
  container.insertBefore(tag, input);
  input.value = '';
}

function getKeywords(containerId) {
  const c = document.getElementById(containerId);
  if (!c) return [];
  return [...c.querySelectorAll('.kw-tag')].map(t => t.textContent.replace('×','').trim()).filter(Boolean);
}

/* ── Init ────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  applyAuthUI();
  setupKeywordInput('search-kw-input', 'search-kw-tags', searchFoundFiles);
  setupKeywordInput('dl-kw-input', 'dl-kw-tags', searchDownloadedFiles);

  loadFavSet().then(() => {
    loadFoundFiles();
    loadDownloadedFiles();
  });

  // Fermer les modales avec Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
  });
});
