/**
 * auth.js — gestion JWT, intercepteur API, affichage conditionnel selon rôle
 */

const Auth = {
  getToken: () => localStorage.getItem('auth_token'),
  getUser: () => {
    try { return JSON.parse(localStorage.getItem('auth_user') || 'null'); } catch { return null; }
  },
  isLoggedIn: () => !!localStorage.getItem('auth_token'),
  isAdmin: () => {
    const u = Auth.getUser();
    return u && u.role === 'admin';
  },
  setToken(token, user) {
    localStorage.setItem('auth_token', token);
    if (user) localStorage.setItem('auth_user', JSON.stringify(user));
  },
  logout() {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_user');
    window.location.href = '/login';
  },
  // Renouvelle le token via POST /auth/refresh ; retourne true si succès
  async refresh() {
    try {
      const token = Auth.getToken();
      if (!token) return false;
      const r = await fetch('/api/auth/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      });
      if (!r.ok) return false;
      const data = await r.json();
      Auth.setToken(data.access_token, { username: data.username, role: data.role });
      console.log('[Auth] Token renouvelé ✔');
      return true;
    } catch { return false; }
  },
};

// ── Refresh automatique : renouvelle 15 min avant expiration ─────
(function _scheduleAutoRefresh() {
  // Durée du token côté serveur = 8h → on rafraîchit toutes les 7h30
  const REFRESH_INTERVAL_MS = (8 * 60 - 30) * 60 * 1000;
  setInterval(async () => {
    if (Auth.isLoggedIn()) {
      const ok = await Auth.refresh();
      if (!ok) Auth.logout();
    }
  }, REFRESH_INTERVAL_MS);
})();

/**
 * API helper avec token JWT automatique.
 * Pour les routes publiques (GET /files, thumbnails), pas de token requis.
 */
const API = {
  _headers(extra = {}) {
    const h = { 'Content-Type': 'application/json', ...extra };
    const token = Auth.getToken();
    if (token) h['Authorization'] = `Bearer ${token}`;
    return h;
  },
  async _fetch(method, path, body, isFormData = false, _retry = true) {
    const opts = { method, headers: isFormData ? {} : this._headers() };
    if (isFormData) {
      const token = Auth.getToken();
      if (token) opts.headers['Authorization'] = `Bearer ${token}`;
    }
    if (body) opts.body = isFormData ? body : JSON.stringify(body);
    const r = await fetch('/api' + path, opts);
    if (r.status === 401) {
      // Tente un refresh une seule fois avant de déconnecter
      if (_retry) {
        const ok = await Auth.refresh();
        if (ok) return API._fetch(method, path, body, isFormData, false);
      }
      Auth.logout();
      return;
    }
    if (!r.ok) {
      const err = await r.json().catch(() => ({ detail: r.statusText }));
      throw err;
    }
    if (r.status === 204) return null;
    return r.json();
  },
  get: (path) => API._fetch('GET', path),
  post: (path, body) => API._fetch('POST', path, body),
  put: (path, body) => API._fetch('PUT', path, body),
  patch: (path, body) => API._fetch('PATCH', path, body),
  delete: (path) => API._fetch('DELETE', path),
  postForm: (path, formData) => API._fetch('POST', path, formData, true),
};

/**
 * Met à jour l'interface selon l'état d'authentification.
 * - Affiche/masque les éléments marqués data-auth="required" ou data-auth="admin"
 * - Met à jour la topbar
 */
function applyAuthUI() {
  const loggedIn = Auth.isLoggedIn();
  const isAdmin = Auth.isAdmin();
  const user = Auth.getUser();

  // Éléments visibles seulement si connecté
  document.querySelectorAll('[data-auth="required"]').forEach(el => {
    el.style.display = loggedIn ? '' : 'none';
  });
  // Éléments visibles seulement si admin
  document.querySelectorAll('[data-auth="admin"]').forEach(el => {
    el.style.display = isAdmin ? '' : 'none';
  });
  // Éléments visibles seulement si NON connecté
  document.querySelectorAll('[data-auth="guest"]').forEach(el => {
    el.style.display = loggedIn ? 'none' : '';
  });

  // Topbar user info
  const userInfo = document.getElementById('topbar-user');
  if (userInfo) {
    const themeBtn = `<button class="btn-theme" id="theme-toggle-btn" onclick="toggleTheme()" title="Changer de thème">☀</button>`;
    if (loggedIn && user) {
      userInfo.innerHTML = `
        ${themeBtn}
        <span class="topbar-username">
          <span class="role-badge role-${user.role}">${user.role === 'admin' ? '👑' : '👤'}</span>
          ${user.username}
        </span>
        <button class="btn btn-danger btn-sm" onclick="Auth.logout()">Déconnexion</button>
      `;
    } else {
      userInfo.innerHTML = `${themeBtn}<a href="/login" class="btn btn-primary btn-sm">Se connecter</a>`;
    }
    // Appliquer le thème sauvegardé
    _applyTheme(localStorage.getItem('theme') || 'dark');
  }

  // Onglets de navigation — masquer crawl/headers si non connecté
  const navCrawl = document.querySelector('[data-nav="crawl"]');
  const navHeaders = document.querySelector('[data-nav="headers"]');
  if (navCrawl) navCrawl.style.display = loggedIn ? '' : 'none';
  if (navHeaders) navHeaders.style.display = loggedIn ? '' : 'none';
}

/* ── Theme toggle ─────────────────────────────────────────────── */
function _applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  const btn = document.getElementById('theme-toggle-btn');
  if (btn) btn.textContent = theme === 'dark' ? '☀' : '🌙';
}

function toggleTheme() {
  const cur = localStorage.getItem('theme') || 'dark';
  _applyTheme(cur === 'dark' ? 'light' : 'dark');
}

// Appliquer immédiatement au chargement (avant DOMContentLoaded)
(function() {
  const t = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', t);
})();
